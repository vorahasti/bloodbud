package com.bloodbud;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private Spinner dropdown;
    private static EditText fullName, emailId, mobileNumber, address, city, pincode, password, confirmPassword;
    private static TextView login;
    private static Button signUpButton;
    private static CheckBox terms_conditions;
    private ProgressDialog progressDialog;
    private String bloodGroup = "A+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dropdown = (Spinner) findViewById(R.id.bloodGroup);
        String[] items = new String[]{"A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        fullName = (EditText) findViewById(R.id.fullName);
        emailId = (EditText) findViewById(R.id.userEmailId);
        mobileNumber = (EditText) findViewById(R.id.mobileNumber);
        address = (EditText) findViewById(R.id.address);
        city = (EditText) findViewById(R.id.city);
        pincode = (EditText) findViewById(R.id.pincode);
        password = (EditText) findViewById(R.id.password);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);
        signUpButton = (Button) findViewById(R.id.signUpBtn);
        login = (TextView) findViewById(R.id.already_user);
        terms_conditions = (CheckBox) findViewById(R.id.terms_conditions);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
    }

    // Check Validation Method
    private void checkValidation() {
        // Get all edittext texts
        String getFullName = fullName.getText().toString();
        String getEmailId = emailId.getText().toString();
        String getMobileNumber = mobileNumber.getText().toString();
        String getAddress = address.getText().toString();
        String getCity = city.getText().toString();
        String getPincode = pincode.getText().toString();
        String getPassword = password.getText().toString();
        String getConfirmPassword = confirmPassword.getText().toString();

        // Check if all strings are null or not
        if (getFullName.equals("") || getFullName.length() == 0
                || getEmailId.equals("") || getEmailId.length() == 0
                || getMobileNumber.equals("") || getMobileNumber.length() == 0
                || getAddress.equals("") || getAddress.length() == 0
                || getCity.equals("") || getCity.length() == 0
                || getPincode.equals("") || getPincode.length() == 0
                || getPassword.equals("") || getPassword.length() == 0
                || getConfirmPassword.equals("")
                || getConfirmPassword.length() == 0)
            Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();

            // Check if email id valid or not
        else if (!(getEmailId.contains("@")&&getEmailId.contains(".")))
            Toast.makeText(this, "Your Email Id is Invalid.", Toast.LENGTH_SHORT).show();

            // Check if both password should be equal
        else if (!getConfirmPassword.equals(getPassword))
            Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT).show();

            // Make sure user should check Terms and Conditions checkbox
        else if (!terms_conditions.isChecked())
            Toast.makeText(this, "Please select Terms and Conditions.", Toast.LENGTH_SHORT).show();

            // Else do signup or do your stuff
        else {
            Toast.makeText(this, "Do SignUp.", Toast.LENGTH_SHORT).show();
            uploadToServer(getFullName, getEmailId, getMobileNumber, getPassword, getAddress, getCity, getPincode, bloodGroup);
        }
    }

    public void signUp(){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("fullname", fullName.getText().toString());
        editor.putString("email", emailId.getText().toString());
        editor.putString("password", password.getText().toString());
        editor.commit();
    }

    public void uploadToServer(final String fullname, final String email, final String mobile, final String password
            , final String address, final String city, final String pincode, final String bloodGroup){
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Registering Device...");
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://uniteapp.000webhostapp.com/registeruser.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response){
                        progressDialog.dismiss();
                        if(response!=null){
                            Log.e("Signup Response", response);
                            Toast.makeText(RegisterActivity.this, response, Toast.LENGTH_LONG).show();
                            onSuccessSignup();
                        }
                        else{
                            Toast.makeText(RegisterActivity.this, "Null Response", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("fullname", fullname);
                params.put("email", email);
                params.put("mobile", mobile);
                params.put("password", password);
                params.put("address", address);
                params.put("city", city);
                params.put("pincode", pincode);
                params.put("bloodGroup", bloodGroup);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        Log.e("Request", stringRequest.toString());
        requestQueue.add(stringRequest);

    }

    public void onSuccessSignup(){
        signUp();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}
